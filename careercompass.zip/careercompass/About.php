 

<section id="content" style="background-color:lightgrey">
	<section class="section-padding">
		<div class="container">
			<div class="row showcase-section">
				<div class="col-md-7">
					<img src="about.jpg" alt="showcase image">
				</div>
				<div class="col-md-5">
					<div class="about-text">
						<h3>Our Commitment</h3>
						<p>CareerCompass is committed to fostering a diverse and inclusive community. We believe that diversity fuels innovation and enriches the professional landscape. Our platform is designed to connect talents of all backgrounds with employers who recognize and value the unique contributions each individual brings to the table.</p>
						 <p>Join us on this transformative journey—whether you're a job seeker navigating your career path or an employer seeking top talent. Let CareerCompass be your guide, helping you navigate the dynamic world of opportunities and possibilities. Your success is our compass; let's chart your course together.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="container" >
					
					<div class="about" >
				
						
						<div class="row" >
							<div class="col-md-4">
								<!-- Heading and para -->
								<div class="block-heading-two">
									<h3><span>Why Choose Us?</span></h3>
								</div>
								<p >Choosing us as your job portal means gaining access to a dynamic platform that goes beyond basic job listings. Our user-centric approach prioritizes personalized career development with tailored resources, from skill assessments to targeted training. Our intuitive interface simplifies the job search process, saving you time and effort. With a commitment to connecting talent with opportunities.</p>
							</div>
							<div class="col-md-4" >
								<div class="block-heading-two" >
									<h3><span>Our Solution</span></h3>
								</div>		
								<!-- Accordion starts -->
								<div class="panel-group" id="accordion-alt3">
								 <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
								  <div class="panel" style="background-color:lightgrey">	
									<!-- Panel heading -->
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
											<i class="fa fa-angle-right"></i> Advanced Job Matching Algorithm
										  </a>
										</h4>
									 </div>
									 <div id="collapseOne-alt3" class="panel-collapse collapse">
										<!-- Panel body -->
										<div class="panel-body">
										We employ a cutting-edge job matching algorithm powered by artificial intelligence. This sophisticated system analyzes user profiles and job listings, providing users with highly personalized job recommendations. By continuously learning and adapting, our algorithm ensures that job matches become increasingly accurate over time, enhancing the efficiency of the job search process.
										</div>
									 </div>
								  </div>
								  <div class="panel" style="background-color:lightgrey">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseTwo-alt3">
											<i class="fa fa-angle-right"></i> User-friendly Application Process
										  </a>
										</h4>
									 </div>
									 <div id="collapseTwo-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										We prioritize a seamless and user-friendly application process. With features such as a simple resume upload, one-click apply, and an intuitive application tracking system, we aim to streamline the user experience. This not only saves time for job seekers but also increases the likelihood of successful job placements by creating a hassle-free application journey.
										</div>
									 </div>
								  </div>
								  <div class="panel" style="background-color:lightgrey">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseThree-alt3">
											<i class="fa fa-angle-right"></i> Diverse Job Categories and Industries
										  </a>
										</h4>
									 </div>
									 <div id="collapseThree-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										Explore a vast array of job opportunities across diverse categories and industries on CareerCompass. From entry-level to executive positions, our platform caters to a broad audience of job seekers. By providing a comprehensive ecosystem, we attract a wide range of employers, ensuring a diverse and vibrant community for successful job matches.
										</div>
									 </div>
								  </div>
								  <div class="panel" style="background-color:lightgrey">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseFour-alt3">
											<i class="fa fa-angle-right"></i> Real-time Collaboration and Feedback
										  </a>
										</h4>
									 </div>
									 <div id="collapseFour-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										Foster seamless communication between employers and candidates through our real-time collaboration features. From instant messaging to interview scheduling and feedback mechanisms, our platform ensures efficient and transparent interactions. This commitment to open communication empowers both employers and job seekers to make well-informed decisions throughout the hiring process.
										</div>
									 </div>
								  </div>
								</div>
								<!-- Accordion ends -->
								
							</div>
							
							<div class="col-md-4">
								<div class="block-heading-two">
									<h3><span>Our Expertise</span></h3>
								</div>								
								<h6>Web Development</h6>
								<div class="progress pb-sm">
								  <!-- White color (progress-bar-white) -->
								  <div class="progress-bar progress-bar-red" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>Designing</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>User Experience</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-lblue" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
								<h6>Development</h6>
								<div class="progress pb-sm">
								  <div class="progress-bar progress-bar-yellow" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
									 <span class="sr-only">40% Complete (success)</span>
								  </div>
								</div>
							</div>
							
						</div>
						
						 						
						 
						<br>
						<!-- Our Team starts -->
				
						<!-- Heading -->
						<div class="block-heading-six">
							<h4 class="bg-color">Our Team</h4>
						</div>
						<br>
						
						<!-- Our team starts -->
						
						<div class="team-six">
							<div class="row">
								<div class="col-md-4 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="person.png" alt="">
										<!-- Name -->
										<h4>Asad Ullah Khan</h4>
										<span class="deg">CEO</span> 
									</div>
								</div>
								<div class="col-md-4 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="person.png" alt="">
										<!-- Name -->
										<h4>Rohail Rashid Khan</h4>
										<span class="deg">CEO</span> 
									</div>
								</div>
								<div class="col-md-4 col-sm-6">
									<!-- Team Member -->
									<div class="team-member">
										<!-- Image -->
										<img class="img-responsive" src="person.png" alt="">
										<!-- Name -->
										<h4>Arham Mehmood</h4>
										<span class="deg">CEO</span> 
									</div>
								</div>
							</div>
						</div>
						
						<!-- Our team ends -->
					  
						
					</div>
									
				</div>
	</section> 
 