<?php
    if(isset($_POST['submit']))
	{
       // Fetch form data
	   $name = isset($_POST['name']) ? $_POST['name'] : '';
    	$email = isset($_POST['email']) ? $_POST['email'] : '';
    	$message = isset($_POST['message']) ? $_POST['message'] : '';
   
	   // Set the recipient email address
	   $to = 'asadkhanshoeb@gmail.com';
   
	   // Set the subject of the email
	   $subject = 'New Contact Form Submission';
   
	   // Compose the email message
	   $email_message = "Name: $name\n";
	   $email_message .= "Email: $email\n";
	   $email_message .= "Message:\n$message";
   
	   // Additional headers
	   $headers = "From: $email\r\n";
	   $headers .= "Reply-To: $email\r\n";
   
	   // Send the email
	   mail($to, $subject, $email_message, $headers);
	}
?>
	
	<section id="content" style="background-color:lightgrey">
	
	<div class="container">
		<div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
									<h3>Have questions, or need assitance?</h3>
									<p>Stay connected with us on social media! Follow us for updates, job market insights, and quick responses to your messages. We value our online community and look forward to engaging with you.</p>
                                    <p>If you prefer a face-to-face discussion, you are welcome to visit our office at below attached address. Our team will be delighted to assist you in person and provide guidance on utilizing our platform effectively.</p>
								</div>  
							</div>
						</div>
	<div class="row">
								<div class="col-md-6">
									<p>Have questions, or need assistance? Our dedicated support team is here to help!</p>
								  	
		   <!-- Form itself -->
          <form name="sentMessage" id="contactForm" method="post" novalidate>
	       <h3>Contact us</h3>
		 <div class="control-group">
                    <div class="controls">
			<input type="text" class="form-control" 
			   	   placeholder="Full Name" id="name" name="name" required
			           data-validation-required-message="Please enter your name" />
			  <p class="help-block"></p>
		   </div>
	         </div> 	
                <div class="control-group">
                  <div class="controls">
			<input type="email" class="form-control" placeholder="Email" 
			   	            id="email" name="email" required
			   		   data-validation-required-message="Please enter your email" />
		</div>
	    </div> 	
			  
               <div class="control-group">
                 <div class="controls">
				 <textarea rows="10" cols="100" class="form-control" 
                       placeholder="Message" id="message" name="message" required
		       data-validation-required-message="Please enter your message" minlength="5" 
                       data-validation-minlength-message="Min 5 characters" 
                        maxlength="999" style="resize:none"></textarea>
		</div>
               </div> 		 
	     <div id="success"> </div> <!-- For success/fail messages -->
	    <button type="submit" name= "submit" class="btn btn-primary pull-right">Send</button><br />
          </form>
								</div>
								<div class="col-md-6">
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:600px;"><div id="gmap_canvas" style="height:500px;width:600px;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://www.trivoo.net" id="get-map-data">trivoo</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(24.8568991,67.2646838),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(24.8568991,67.2646838)});infowindow = new google.maps.InfoWindow({content:"<b>FAST NUCES</b><br/>Shah Latif Town<br/> Karachi" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
								</div>
							</div>
	</div>
 
	</section>
 