  <section id="banner">
   
  <!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img style="width: 100%; height: 720px; object-fit: cover;  filter: brightness(80%) blur(2px)" src="<?php echo web_root; ?>plugins/home-plugins/img/slides/pick_1.jpg" alt="" />

                <div class="flex-caption">
                    <h3 style="color:lightgray">innovation</h3> 
          <p style= "color:lightgray">We create the opportunities</p> 
           
                </div>
              </li>
              <li>
                <img style="width: 100%; height: 720px; object-fit: cover; filter: brightness(80%)  blur(2px)" src="<?php echo web_root; ?>plugins/home-plugins/img/slides/pick_2.jpg" alt="" />
                <div class="flex-caption">
                    <h3 style="color:lightgray">Specialize</h3> 
          <p style="color:lightgray">Success depends on work</p> 
           
                </div>
              </li>
            </ul>
        </div>
  <!-- end slider -->
 
  </section> 
  <section id="call-to-action-2" style = "background-color: #454545">
    <div class="container" >
      <div class="row" >
        <div class="col-md-10 col-sm-9">
          <h3 style="color:lightgray">Partner with Business Leaders</h3>
          <p style="color:lightgray">Development of successful, long term, strategic relationships between customers and suppliers, based on achieving best practice and sustainable competitive advantage. In the business partner model, HR professionals work closely with business leaders and line managers to achieve shared organisational objectives.</p>
        </div>
       <!--  <div class="col-md-2 col-sm-3">
          <a href="#" class="btn btn-primary">Read More</a>
        </div> -->
      </div>
    </div>
  </section>
  
  <section id="content" style="background-color:#eaeaea;" >
  
  
  <div class="container" >
        <div class="row">
      <div class="col-md-12" >
        <div class="aligncenter"><h2 class="aligncenter">Company</h2><!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus ovident, doloribus omnis minus temporibus perferendis nesciunt.. --></div>
        <br/>
      </div>
    </div>

    <?php 
      $sql = "SELECT * FROM `tblcompany`";
      $mydb->setQuery($sql);
      $comp = $mydb->loadResultList();


      foreach ($comp as $company ) {
        # code...
    
    ?>
            <div class="col-sm-4 info-blocks" style="background-color: #eaeaea;">
                <i class="icon-info-blocks fa fa-building-o"></i>
                <div class="info-blocks-in" >
                    <h3><?php echo $company->COMPANYNAME;?></h3>
                    <!-- <p><?php echo $company->COMPANYMISSION;?></p> -->
                    <p>Address :<?php echo $company->COMPANYADDRESS;?></p>
                    <p>Contact No. :<?php echo $company->COMPANYCONTACTNO;?></p>
                </div>
            </div>

    <?php } ?> 
  </div>
  </section>
  
  <section class="section-padding gray-bg"  style="background-color: #eaeaea;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-title text-center">
            <h2 >Popular Jobs</h2>  
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 ">
          <?php 
            $sql = "SELECT * FROM `tblcategory`";
            $mydb->setQuery($sql);
            $cur = $mydb->loadResultList();

            foreach ($cur as $result) {
              echo '<div class="col-md-3" style="font-size:15px;padding: left 5px; color:#454545;">* <b><a href="'.web_root.'index.php?q=category&search='.$result->CATEGORY.'">'.$result->CATEGORY.'</a></b></div>';
            }

          ?>
        </div>
      </div>
 
    </div>
  </section>    
  <section id="content-3-10" class="content-block data-section nopad content-3-10">
  <div class="image-container col-sm-6 col-xs-12 pull-left">
    <div class="background-image-holder">
    </div>
  </div>

  <div class="container-fluid" style="background-color: #eaeaea;">
    <div class="row">
      <div class="col-sm-6 col-sm-offset-6 col-xs-12 content" style="background-color: lightgrey;">
        <div class="editContent">
          <h3>Our Team</h3>
        </div>
        <div class="editContent"  style="height:235px;">
          <p> 
          &nbsp;&nbsp;Our "one team" attitude breaks down silos and helps us engage equally effectively from the C-suite to the front line. Our collaborative working style emphasizes teamwork, trust, and tolerance for diverging opinions. People tell us we are down-to-earth, approachable and fun.<br/><br/>

          &nbsp;&nbsp;We have a passion for our clients' true results and a pragmatic drive for action that starts Monday morning 8am and doesn't let up. We rally clients with our infectious energy, to make change stick.<br/><br/>

          &nbsp;&nbsp;And we never go it alone. We support and are supported to develop our own personal results stories. We balance challenging and co-creating with our clients, building the internal capabilities required for them to create repeatable results. </p>
        </div> 
      </div>
    </div><!-- /.row-->
  </div><!-- /.container -->
</section>
  
  <div class="about home-about" style="background-color: #eaeaea;">
        <div class="container" >
            
            <div class="row">
              <div class="col-md-4">
                <!-- Heading and para -->
                <div class="block-heading-two">
                  <h3><span>Why us?</span></h3>
                </div>
                <p>Choosing us as your job portal means gaining access to a dynamic platform that goes beyond basic job listings. Our user-centric approach prioritizes personalized career development with tailored resources, from skill assessments to targeted training. Our intuitive interface simplifies the job search process, saving you time and effort. With a commitment to connecting talent with opportunities.</p>

              </div>
              <div class="col-md-4" >
                <div class="block-heading-two">
                  <h3><span>Latest News</span></h3>
                </div>    
                <!-- Accordion starts -->
                <div class="panel-group" id="accordion-alt3">
                 <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
                  <div class="panel" style="background-color: #eaeaea;"> 
                  <!-- Panel heading -->
                   <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
                      <i class="fa fa-angle-right"></i> Quantum Computing Breakthrough
                      </a>
                    </h4>
                   </div>
                   <div id="collapseOne-alt3" class="panel-collapse collapse">
                    <!-- Panel body -->
                    <div class="panel-body">
                    Researchers have achieved a significant milestone in quantum computing, developing a new quantum processor that demonstrates unprecedented computational power. This breakthrough paves the way for more complex simulations and problem-solving capabilities in fields such as cryptography and materials science.
                    
                    </div>
                   </div>
                  </div>
                  <div class="panel" style="background-color: #eaeaea;">
                   <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseTwo-alt3">
                      <i class="fa fa-angle-right"></i> AI in Healthcare Advancements
                      </a>
                    </h4>
                   </div>
                   <div id="collapseTwo-alt3" class="panel-collapse collapse">
                    <div class="panel-body">
                    Recent advancements in artificial intelligence (AI) applications for healthcare have led to the creation of innovative diagnostic tools. AI algorithms are now capable of analyzing medical imaging data with remarkable accuracy, assisting healthcare professionals in early detection and personalized treatment plans.
                    </div>
                   </div>
                  </div>
                  <div class="panel"style="background-color: #eaeaea;">
                   <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseThree-alt3">
                      <i class="fa fa-angle-right"></i> Space-Based Internet Constellations
                      </a>
                    </h4>
                   </div>
                   <div id="collapseThree-alt3" class="panel-collapse collapse">
                    <div class="panel-body">
                    Companies are making significant progress in deploying satellite constellations to provide global internet coverage. These space-based networks aim to bridge the digital divide by delivering high-speed internet access to remote and underserved regions, fundamentally transforming the way people connect and communicate worldwide.

                    </div>
                   </div>
                  </div>
                  <div class="panel"style="background-color: #eaeaea;">
                   <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseFour-alt3">
                      <i class="fa fa-angle-right"></i> Augmented Reality (AR) in Manufacturing
                      </a>
                    </h4>
                   </div>
                   <div id="collapseFour-alt3" class="panel-collapse collapse">
                    <div class="panel-body">
                    The integration of augmented reality in manufacturing processes is revolutionizing industrial operations. AR technologies are enhancing worker efficiency by providing real-time data overlays, interactive instructions, and immersive training experiences, ultimately optimizing productivity and reducing errors on the factory floor.

                    </div>
                   </div>
                  </div>
                </div>
                <!-- Accordion ends -->
                
              </div>
              
              <div class="col-md-4">
                <div class="block-heading-two">
                  <h3><span>Testimonials</span></h3>
                </div>  
                     <div class="testimonials">
                    <div class="active item">
                      <blockquote><p>"Career Compass transformed my job search journey! With its intuitive interface and personalized recommendations, I quickly found the perfect job match. The platform's comprehensive resources and user-friendly design make it a standout choice for anyone navigating the professional landscape."</p></blockquote>
                      <div class="carousel-info">
                      <img alt="" src="uni.png" class="pull-left">
                      <div class="pull-left">
                        <span class="testimonials-name">Arham Mehmood</span>
                        <span class="testimonials-post">Technical Director</span>
                      </div>
                      </div>
                    </div>
                  </div>
              </div>
              
            </div>
            
                        
             
            <br>
           
            </div>
            
          </div>